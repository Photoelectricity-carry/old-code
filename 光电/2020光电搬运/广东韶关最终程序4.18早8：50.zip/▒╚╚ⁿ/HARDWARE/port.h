#ifndef __PORT_H
#define __PORT_H	
#include "sys.h" 
#define LED6 PGout(4)//   1
#define LED2 PGout(5)// 	2
#define LED3 PGout(6)//   3
#define LED4 PGout(7)//   4 
#define LED5 PGout(8)//   5
void Port_Init(void);
	 				    
#endif

