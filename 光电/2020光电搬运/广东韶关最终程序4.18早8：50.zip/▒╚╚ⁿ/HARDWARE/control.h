#ifndef __CONTROL_H
#define __CONTROL_H

#include "sys.h"

void chumen();
void go_dian();
void go_wu();
void left45();
void right45();
void left90();
void right90();
void left135();
void right135();
#endif

