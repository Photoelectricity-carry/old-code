#ifndef __TURN_H
#define __TURN_H

#include "sys.h"

void Turn45(u8 direction,u16 time);
void Turn90(u8 direction,u16 time);
void Turn135(u8 direction,u16 time);
void Turn180(u8 direction,u16 time);
void Turn_weizhuan(u8 direction);

#endif

