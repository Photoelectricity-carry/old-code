#ifndef __SPEED_H
#define __SPEED_H

#include "sys.h"

void Speed(u16 Left,u16 Right);
void stop();


void weiqianjin_quick(u16 q);
void weiqianjin_slow(u16 q);


void weihoutui_quick(u16 h);
void weihoutui_slow(u16 h);

#endif



