#ifndef __DIRECTION_H
#define __DIRECTION_H

#include "sys.h"	 

void Direction(u8 left,u8 right);
void turnleft(u16 x);
void turnright(u16 x);
void turnleft1(u16 x);
void turnright1(u16 x);
#endif

