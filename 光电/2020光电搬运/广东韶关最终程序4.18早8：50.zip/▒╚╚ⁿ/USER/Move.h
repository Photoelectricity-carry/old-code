#ifndef _Move_H
#define _Move_H

#include <usart.h>
#include <sys.h>
#include <delay.h>
//#include <TRACK.h>
void A1_colour_go(u16 n);
void C1_colour_go(u16 n);
void E1_colour_go(u16 n);

void A2_colour_go(u16 n);
void B2_colour_go(u16 n);
void C2_colour_go(u16 n);
void D2_colour_go(u16 n);
void E2_colour_go(u16 n);
#endif
