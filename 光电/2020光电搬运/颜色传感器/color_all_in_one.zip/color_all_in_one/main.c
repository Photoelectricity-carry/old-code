#include <stm32f10x.h>
#include <stdio.h>
#include "color_all_in_one.h"


int main(void)
{
	//��������
	u16 RGB[3];
	
  color_init();
	
	while(1)
	{
	   get_color(RGB);	
  }

}
