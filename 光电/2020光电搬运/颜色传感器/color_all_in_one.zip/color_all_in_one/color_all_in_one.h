#ifndef __COLOR_ALL_IN_ONE_H
#define __COLOR_ALL_IN_ONE_H	 
#include "stm32f10x.h"
#include "stm32f10x_exti.h"

  
//���岿��
#define BITBAND(addr, bitnum) ((addr & 0xF0000000)+0x2000000+((addr &0xFFFFF)<<5)+(bitnum<<2)) 
#define MEM_ADDR(addr)  *((volatile unsigned long  *)(addr)) 
#define BIT_ADDR(addr, bitnum)   MEM_ADDR(BITBAND(addr, bitnum)) 
#define GPIOA_ODR_Addr    (GPIOA_BASE+12) //0x4001080C 
#define PAout(n)   BIT_ADDR(GPIOA_ODR_Addr,n)  //��� 
#define PAin(n)    BIT_ADDR(GPIOA_IDR_Addr,n)  //���� 
#define S0 PAout(0)
#define S1 PAout(1)
#define S2 PAout(2)
#define S3 PAout(3)
#define OUT PAin(4)

extern double amount;
extern double Rgena,Ggena,Bgena;
extern double Ramount,Gamount,Bamount;
	
  void get_color(u16 *RGB);
  void color_init(void);
	u16 get_Rcolor(void);
	u16 get_Gcolor(void);
	u16 get_Bcolor(void);
#endif
