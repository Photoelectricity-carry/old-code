#ifndef _GRAY_H
#define _GRAY_H
#include "stm32f4xx.h"

void Gray_init(void);

#endif
