/**
  ****************************(C) COPYRIGHT 2016 DJI****************************
  * @file       freeRTOS_middle.c/h
  * @brief      freeRTOS���м�㣬���δ��ʱ�жϺ�ͳ��������ʱ�Ľӿں����ŵ�����.
  * @history
  *  Version    Date            Author          Modification
  *  V1.0.0     Dec-26-2018     RM              1. ���
  *
  @verbatim
  ==============================================================================

  ==============================================================================
  @endverbatim
  ****************************(C) COPYRIGHT 2016 DJI****************************
  */

#ifndef FREERTOS_MIDDLEWARE_H
#define FREERTOS_MIDDLEWARE_H
#include "main.h"

#endif
