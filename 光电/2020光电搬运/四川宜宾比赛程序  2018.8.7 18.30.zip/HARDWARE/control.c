#include "control.h"
#include "speed.h"
#include "track.h"
#include "gouzi.h"
#include "turn.h"
void chumen()
{
	stop();
	Track_delay(700);

	test_right ();  //�е���
	stop();
	
	Track_delay(80);
	
	test_right ();  //�е���
	stop();
}

void go_dian()
{
	Track_delay(500);
	stop();

	test();
	
	jiazi(1);	
	stop();
	
	xunji(400);
	
	stop();
	
	test();
	
	test_right();
	
	
}

void go_wu()
{
	Track_delay(700);
	stop();
	
	test();
	
	jiazi(0);
	stop();
	
	xunji(200);
	stop();
	
	test();
	
	test_right();
}

void left45()
{
		stop();
		test_right();
	
		stop();
		Turn45(0,420);  //��ת45
		stop();
	
		qianjin(150);
	
		turn_adgust(1,0);
}

void right45()
{
		stop();
		test_right();
	
		stop();
		Turn45(1,360);  //��ת45
		stop();
	
		houtui(80);
	
		turn_adgust(0,1);
}

void left90()
{
		stop();
		test_right();
	
		stop();
		Turn90(0,650);  //��ת45
		stop();
	
		qianjin(135);
	
		turn_adgust(1,0);
}
void right90()
{
		stop();
		test_right();
	
		stop();
		Turn90(1,650);  //��ת45
		stop();
	
//		houtui(80);
	
		turn_adgust(0,1);
}

void left135()
{
		stop();
		test_right();
	
		stop();
		Turn135(0,900);  //��ת
		stop();
	
		qianjin(110);
	
		turn_adgust(1,0);
}

void right135()
{
		stop();
		test_right();
	
		stop();
		Turn135(1,800);  //��ת45
		stop();
	
//		houtui(80);
	
		turn_adgust(0,1);
}