#include "gouzi.h"
#include "pwm.h"
#include "delay.h"
#include "speed.h"
void  gouzi1(u16 x)
{
//	TIM4_PWM_CH4_Init(19999,71,x);	
	TIM2_PWM_CH3_Init(19999,71,x);
}

void  gouzi21(u16 x)
{
	TIM3_PWM_CH1_Init(19999,71,x);	
}
void  gouzi31(u16 x)
{
	TIM3_PWM_CH3_Init(19999,71,x);	//b7
}
void  gouzi41(u16 x)
{
	TIM3_PWM_CH4_Init(19999,71,x);
}
void  gouzi51(u16 x)
{
	TIM2_PWM_CH4_Init(19999,71,x);
}
void  gouzi61(u16 x)
{
	TIM2_PWM_CH3_Init(19999,71,x);
}

void jiazi(u16 x)  //x=0ʱ���ر�   x=1 ʱ����
{
	if(x==0)
	{
		gouzi1(1950);
	}
	else if(x==1)
	{
		gouzi1(500);  
		
	}
}
void gouzi5(u16 x)//x=0ʱ,zuo    x=1 ʱ��you
{
	if(x==0)
	{
		
		
		gouzi21(700);  //shang  //����
		gouzi21(1500);  //xia
		
		gouzi31(510);  //��  //����
		gouzi31(1500);  //��
		
		gouzi51(700);  //shang  //����
		gouzi51(1500);  //xia
		
		gouzi41(1500);   //��  //����
	  gouzi41(700);     //��
	} 
	else if(x==1)
	{}
}

void left_zhua()
{
	
jiazi(0);
		
	weihoutui1();
	stop();
	
	gouzi21(600);  //shang 
	delay_ms(1000,0);
	delay_ms(1000,0);
	
	gouzi31(790);  //ת��
	delay_ms(1000,0);
	delay_ms(1000,0);
	
	gouzi21(1600);  //����
	delay_ms(1000,0);
	delay_ms(1000,0);
	
	gouzi31(1500);  //ת��
	delay_ms(1000,0);
	delay_ms(1000,0);
	
}

void left_fang()
{
	
	gouzi31(600);  //ת��
	delay_ms(1000,0);
	delay_ms(1000,0);
	
	gouzi21(650);  //����
	delay_ms(1000,0);
	delay_ms(1000,0);
	
	gouzi31(1500);  //ת��
	delay_ms(1000,0);
	delay_ms(1000,0);
	
}
void right_zhua()
{
	jiazi(0);
		
	stop();
	weihoutui1();
	stop();
	
	gouzi51(2000);  //shang
	delay_ms (1000,0);
	delay_ms (1000,0);
	
	gouzi41(1400);   //�� 
	delay_ms (1000,0);
	delay_ms (1000,0);
	
	gouzi51(1000);  //xia
	delay_ms (1000,0);
	delay_ms (1000,0);
	
	gouzi41(500);     //��
	delay_ms (1000,0);
	delay_ms (1000,0);
}
void right_fang()
{
	gouzi41(1400);   //�� 
	delay_ms (1000,0);
	delay_ms (1000,0);
	
	gouzi51(2000);  //shang
	delay_ms (1000,0);
	delay_ms (1000,0);
	delay_ms (1000,0);
	
	gouzi41(700);     //��
	delay_ms (1000,0);
	delay_ms (1000,0);
	
}
	