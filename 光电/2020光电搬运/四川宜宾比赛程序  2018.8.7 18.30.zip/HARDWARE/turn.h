#ifndef _PWM_H
#define _PWM_H

	#include "sys.h"
	void Port_Init(void);
#endif
