#ifndef __PORT_H
#define __PORT_H	
#include "sys.h" 

void Port_Init(void);
		 				    
#endif

