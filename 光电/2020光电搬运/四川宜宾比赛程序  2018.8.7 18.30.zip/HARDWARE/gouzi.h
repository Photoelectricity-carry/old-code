#ifndef __GOUZI_H
#define __GOUZI_H

#include "sys.h"

void  gouzi1(u16 x);
void  gouzi21(u16 x);
void  gouzi31(u16 x);
void  gouzi41(u16 x);
void  gouzi51(u16 x);
void  gouzi61(u16 x);
void jiazi(u16 x) ;

void left_zhua();
void left_fang();
void right_zhua();
void right_fang();
#endif

