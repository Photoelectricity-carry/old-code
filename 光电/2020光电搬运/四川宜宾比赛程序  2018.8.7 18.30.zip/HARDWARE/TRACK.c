#include "TRACK.h"
#include "speed.h"
#include "delay.h"
#include "direction.h"
#include "turn.h"
#include "sys.h"

void track()//ǰ��ѭ��
{
u16 left,right;
left=935;
right=1000;	

if( A3==0 && A2==1 && A1==1&& A0==0 )
	//0110
		{Direction (1,1);Speed (left,right);delay_ms(10,0);}
		
else if(  A3==0 && A2==1 && A1==0 && A0==0)
	//0100
		{Direction (1,1);Speed (left-150,right+400);delay_ms(10,0);}
		
else if(  A3==0 && A2==0 && A1==1 && A0==0)
	//0010
		{Direction (1,1);Speed (left+400,right-150);delay_ms(10,0);}
		
else if(  A3==1 && A2==1 && A1==0 && A0==0)
	//1100
		{Direction (1,1);Speed (left-150,right+380);delay_ms(10,0);}
		
else if(  A3==0 && A2==0 && A1==1 && A0==1)
	//0011
		{Direction (1,1);Speed (left+430,right-280);delay_ms(10,0);}
		
else if(  A3==1 && A2==0 && A1==0 && A0==0)
	//1000
		{Direction (1,1);Speed (left-150,right+600);delay_ms(10,0);}
		
else if(  A3==0 && A2==0 && A1==0 && A0==1)
	//0001
		{Direction (1,1);Speed (left+600,right-150);delay_ms(10,0);}

else
		{Direction (1,1);Speed (left,right);delay_ms(10,0);}
		
	}

	

	
	
void track_back()//����ѭ��
{
u16 left,right;
left=1300;
right=1300;	

if( B3==1 && B2==0 && B1==0&& B0==1 )
	//0110
		{Direction (0,0);Speed (left,right);delay_ms(10,0);}
		
else if(  B3==1 && B2==0 && B1==1&& B0==1)
	//0100
		{Direction (0,0);Speed (left+275,right-275);delay_ms(10,0);}
		
else if(  B3==1 && B2==1 && B1==0&& B0==1)
	//0010
		{Direction (0,0);Speed (left-300,right+275);delay_ms(10,0);}
		
else if(  B3==0 && B2==0 && B1==1&& B0==1)
	//1100
		{Direction (0,0);Speed (left+250,right-250);delay_ms(10,0);}
		
else if(  B3==1 && B2==1 && B1==0&& B0==0)
	//0011
		{Direction (0,0);Speed (left-500,right+450);delay_ms(10,0);}
		
else if(  B3==0 && B2==1 && B1==1&& B0==1)
	//1000
		{Direction (0,0);Speed (left+400,right-400);delay_ms(10,0);}
		
else if(  B3==1 && B2==1 && B1==1&& B0==0)
	//0001
		{Direction (0,0);Speed (left-500,right+600);delay_ms(10,0);}

else
		{Direction (0,0);Speed (left,right);delay_ms(10,0);}
		
	}
//void track_back()	//houtui xunji 
//{
//u16 left,right;
//left=1100;
//right=1200;	

//if( B3==0 && B2==1 && B1==1&& B0==0 )
//	//0110
//		{Direction (0,0);Speed (left,right);delay_ms(50,0);}
//		
//else if(  B3==0 && B2==1 && B1==0&& B0==0)
//	//0100
//		{Direction (0,0);Speed (left-150,right+150);delay_ms(50,0);}
//		
//else if(  B3==0 && B2==0 && B1==1&& B0==0)
//	//0010
//		{Direction (0,0);Speed (left+130,right-150);delay_ms(50,0);}
//		
//else if(  B3==1 && B2==1 && B1==0&& B0==0)
//	//1100
//		{Direction (0,0);Speed (left-300,right+300);delay_ms(50,0);}
//		
//else if(  B3==0 && B2==0 && B1==1&& B0==1)
//	//0011
//		{Direction (0,0);Speed (left+250,right-300);delay_ms(50,0);}
//		
//else if(  B3==1 && B2==0 && B1==0&& B0==0)
//	//1000
//		{Direction (0,0);Speed (left-450,right+450);delay_ms(50,0);}
//		
//else if(  B3==0 && B2==0 && B1==0&& B0==1)
//	//0001
//		{Direction (0,0);Speed (left+370,right-450);delay_ms(50,0);}

//else
//		{Direction (0,0);Speed (left,right);delay_ms(50,0);}
//		
//	}
//void track_back()	//houtui xunji 
//{
//u16 left,right;
//left=1100;
//right=1200;	

//if( B3==0 && B2==1 && B1==1&& B0==0 )
//	//0110
//		{Direction (0,0);Speed (left,right);delay_ms(10,0);}
//		
//else if(  B3==0 && B2==1 && B1==0&& B0==0)
//	//0100
//		{Direction (0,0);Speed (left-200,right+200);delay_ms(10,0);}
//		
//else if(  B3==0 && B2==0 && B1==1&& B0==0)
//	//0010
//		{Direction (0,0);Speed (left+350,right-200);delay_ms(10,0);}
//		
//else if(  B3==1 && B2==1 && B1==0&& B0==0)
//	//1100
//		{Direction (0,0);Speed (left-350,right+350);delay_ms(10,0);}
//		
//else if(  B3==0 && B2==0 && B1==1&& B0==1)
//	//0011
//		{Direction (0,0);Speed (left+400,right-350);delay_ms(10,0);}
//		
//else if(  B3==1 && B2==0 && B1==0&& B0==0)
//	//1000
//		{Direction (0,0);Speed (left-650,right+650);delay_ms(10,0);}
//		
//else if(  B3==0 && B2==0 && B1==0&& B0==1)
//	//0001
//		{Direction (0,0);Speed (left+650,right-650);delay_ms(10,0);}

//else
//		{Direction (0,0);Speed (left,right);delay_ms(10,0);}
//		
//	}

//	

	

//void track()	//˳ʱ��ѭ��    �Ѹ�3
//{
//u16 left,right;
//left=1420;
//right=1500;	

//if(A4==0 && A3==0 && A2==1 && A1==0 && A0==0)  //3 
//		{Direction (1,1);Speed (left,right);delay_ms(60,0);} 
//	else if(A4==0 && A3==1 && A2==1 && A1==0 && A0==0) //2 3
//		{Direction (1,1);Speed (left,right+360);delay_ms(50,0);}
//	else if(A4==0 && A3==0 && A2==1 && A1==1 && A0==0) // 3 4
//		{Direction (1,1);Speed (left+400,right);delay_ms(50,0);}
//	else if(A4==0 && A3==1 && A2==0 && A1==0 && A0==0) // 2
//		{Direction (1,1);Speed (left,right+180);delay_ms(50,0);}
//	else if(A4==0 && A3==0 && A2==0 && A1==1 && A0==0) // 4
//		{Direction (1,1);Speed (left+440,right);delay_ms(50,0);}
//		
//		
//	else if(A4==1 && A3==1 && A2==0 && A1==0 && A0==0)// 1 2
//		{Direction (1,1);Speed (left,right+350);delay_ms(40,0);}
//	else if(A4==0 && A3==0 && A2==0 && A1==1 && A0==1) // 4 5
//		{Direction (1,1);Speed (left+470,right);delay_ms(40,0);}
//	else if(A4==1 && A3==0 && A2==0 && A1==0 && A0==0) // 1
//		{Direction (1,1);Speed (left,right+450);delay_ms(40,0);}
//	else if(A4==0 && A3==0 && A2==0 && A1==0 && A0==1) // 5
//		{Direction (1,1);Speed (left+500,right);delay_ms(40,0);}
//	else
//		{Direction (1,1);Speed (left,right);delay_ms(60,0);}
//	}
//void track()	//˳ʱ��ѭ��    �Ѹ�4
//{
//u16 left,right;
//left=1150;
//right=1250;	
//Direction (1,1);Speed (left,right);delay_ms(20,0);

//if(A4==0 && A3==0 && A2==1 && A1==0 && A0==0)  //3 
//		{Direction (1,1);Speed (left,right);delay_ms(20,0);} 
//	else if(A4==0 && A3==1 && A2==1 && A1==0 && A0==0) //2 3
//		{Direction (1,1);Speed (left-500,right+600);delay_ms(20,0);}
//	else if(A4==0 && A3==0 && A2==1 && A1==1 && A0==0) // 3 4
//		{Direction (1,1);Speed (left+600,right-500);delay_ms(20,0);}
//	else if(A4==0 && A3==1 && A2==0 && A1==0 && A0==0) // 2
//		{Direction (1,1);Speed (left,right+300);delay_ms(20,0);}
//	else if(A4==0 && A3==0 && A2==0 && A1==1 && A0==0) // 4
//		{Direction (1,1);Speed (left+300,right);delay_ms(20,0);}		
//	else if(A4==1 && A3==1 && A2==0 && A1==0 && A0==0)// 1 2
//		{Direction (1,1);Speed (left,right+700);delay_ms(20,0);}
//	else if(A4==0 && A3==0 && A2==0 && A1==1 && A0==1) // 4 5
//		{Direction (1,1);Speed (left+500,right);delay_ms(20,0);}
//	else if(A4==1 && A3==0 && A2==0 && A1==0 && A0==0) // 1
//		{Direction (1,1);Speed (left,right+700);delay_ms(20,0);}
//	else if(A4==0 && A3==0 && A2==0 && A1==0 && A0==1) // 5
//		{Direction (1,1);Speed (left+500,right);delay_ms(20,0);}
//	else
//		{Direction (1,1);Speed (left,right);delay_ms(20,0);}
//	}

//void track()	//˳ʱ��ѭ��    �Ѹ�4
//{
//u16 left,right;
//left=1150;
//right=1300;	
//Direction (1,1);Speed (left,right);delay_ms(20,0);

//if(A4==0 && A3==0 && A2==1 && A1==0 && A0==0)  //3 
//		{Direction (1,1);Speed (left,right);delay_ms(20,0);} 
//	else if(A4==0 && A3==1 && A2==1 && A1==0 && A0==0) //2 3
//		{Direction (1,1);Speed (left-250,right);delay_ms(20,0);}
//	else if(A4==0 && A3==0 && A2==1 && A1==1 && A0==0) // 3 4
//		{Direction (1,1);Speed (left,right-250);delay_ms(20,0);}
//	else if(A4==0 && A3==1 && A2==0 && A1==0 && A0==0) // 2
//		{Direction (1,1);Speed (left-400,right);delay_ms(20,0);}
//	else if(A4==0 && A3==0 && A2==0 && A1==1 && A0==0) // 4
//		{Direction (1,1);Speed (left,right-400);delay_ms(20,0);}		
//	else if(A4==1 && A3==1 && A2==0 && A1==0 && A0==0)// 1 2
//		{Direction (1,1);Speed (left-600,right);delay_ms(20,0);}
//	else if(A4==0 && A3==0 && A2==0 && A1==1 && A0==1) // 4 5
//		{Direction (1,1);Speed (left,right-350);delay_ms(20,0);}
//	else if(A4==1 && A3==0 && A2==0 && A1==0 && A0==0) // 1
//		{Direction (1,1);Speed (left-600,right);delay_ms(20,0);}
//	else if(A4==0 && A3==0 && A2==0 && A1==0 && A0==1) // 5
//		{Direction (1,1);Speed (left,right-550);delay_ms(20,0);}
//	else
//		{Direction (1,1);Speed (left,right);delay_ms(20,0);}
//	}
//void track()	//  XUN JI    
//{
//u16 left,right;
//left=1179;
//right=1200;	

//if(A4==0 && A3==0 && A2==1 && A1==0 && A0==0)
//		{Direction (1,1);Speed (left,right);delay_ms(50,0);}
//	else if(A4==0 && A3==1 && A2==1 && A1==0 && A0==0)
//		{Direction (1,1);Speed (left,right+150);delay_ms(50,0);}
//	else if(A4==0 && A3==0 && A2==1 && A1==1 && A0==0)
//		{Direction (1,1);Speed (left+110,right);delay_ms(50,0);}
//	else if(A4==0 && A3==1 && A2==0 && A1==0 && A0==0)
//		{Direction (1,1);Speed (left,right+250);delay_ms(50,0);}
//	else if(A4==0 && A3==0 && A2==0 && A1==1 && A0==0)
//		{Direction (1,1);Speed (left+150,right);delay_ms(50,0);}
//	else if(A4==1 && A3==1 && A2==0 && A1==0 && A0==0)
//		{Direction (1,1);Speed (left,right+300);delay_ms(50,0);}
//	else if(A4==0 && A3==0 && A2==0 && A1==1 && A0==1)
//		{Direction (1,1);Speed (left+230,right);delay_ms(50,0);}
//	else if(A4==1 && A3==0 && A2==0 && A1==0 && A0==0)
//		{Direction (1,1);Speed (left,right+450);delay_ms(50,0);}
//	else if(A4==0 && A3==0 && A2==0 && A1==0 && A0==1)
//		{Direction (1,1);Speed (left+380,right);delay_ms(50,0);}
//	else
//		{Direction (1,1);Speed (left,right);delay_ms(50,0);}
//	}
void track1()	     //��ʱ��Ѱ��
{
	u16 left,right;
	left=1420;
	right=1500;	
	
  if(A4==0 && A3==0 && A2==1 && A1==0 && A0==0)
		{Direction (1,1);Speed (left,right);delay_ms(100,0);}
	else if(A4==0 && A3==1 && A2==1 && A1==0 && A0==0)
		{Direction (1,1);Speed (left,right+200);delay_ms(100,0);}
	else if(A4==0 && A3==0 && A2==1 && A1==1 && A0==0)
		{Direction (1,1);Speed (left+150,right);delay_ms(100,0);}
	else if(A4==0 && A3==1 && A2==0 && A1==0 && A0==0)
		{Direction (1,1);Speed (left,right+350);delay_ms(100,0);}
	else if(A4==0 && A3==0 && A2==0 && A1==1 && A0==0)
		{Direction (1,1);Speed (left+300,right);delay_ms(100,0);}
	else if(A4==1 && A3==1 && A2==0 && A1==0 && A0==0)
		{Direction (1,1);Speed (left,right+500);delay_ms(100,0);}
	else if(A4==0 && A3==0 && A2==0 && A1==1 && A0==1)
		{Direction (1,1);Speed (left+450,right);delay_ms(100,0);}
	else if(A4==1 && A3==0 && A2==0 && A1==0 && A0==0)
		{Direction (1,1);Speed (left,right+650);delay_ms(100,0);}
	else if(A4==0 && A3==0 && A2==1 && A1==0 && A0==1)
		{Direction (1,1);Speed (left+600,right);delay_ms(100,0);}
	else
		{Direction (1,1);Speed (left,right);delay_ms(100,0);}
}

void track2()	     //shunʱ��Ѱ��
{
	u16 left,right;
	left=1420;
	right=1500;	
	
  if(A4==0 && A3==0 && A2==1 && A1==0 && A0==0)
		{Direction (1,1);Speed (left,right);delay_ms(100,0);}
	else if(A4==0 && A3==1 && A2==1 && A1==0 && A0==0)
		{Direction (1,1);Speed (left,right+150);delay_ms(100,0);}
	else if(A4==0 && A3==0 && A2==1 && A1==1 && A0==0)
		{Direction (1,1);Speed (left+200,right);delay_ms(100,0);}
	else if(A4==0 && A3==1 && A2==0 && A1==0 && A0==0)
		{Direction (1,1);Speed (left,right+300);delay_ms(100,0);}
	else if(A4==0 && A3==0 && A2==0 && A1==1 && A0==0)
		{Direction (1,1);Speed (left+350,right);delay_ms(100,0);}
	else if(A4==1 && A3==1 && A2==0 && A1==0 && A0==0)
		{Direction (1,1);Speed (left,right+450);delay_ms(100,0);}
	else if(A4==0 && A3==0 && A2==0 && A1==1 && A0==1)
		{Direction (1,1);Speed (left+500,right);delay_ms(100,0);}
	else if(A4==1 && A3==0 && A2==0 && A1==0 && A0==0)
		{Direction (1,1);Speed (left,right+600);delay_ms(100,0);}
	else if(A4==0 && A3==0 && A2==1 && A1==0 && A0==1)
		{Direction (1,1);Speed (left+650,right);delay_ms(100,0);}
	else
		{Direction (1,1);Speed (left,right);delay_ms(100,0);}
}



void Track_delay(u16 time)//ǰ��ѭ��
{
	u16 i;
	for(i=0;i<time;i++)
		{
			track();
		}
	
}

void track_shun(u32 time)
{
	u8 i;
	for(i=0;i<time;i++)
		{
			track2();
		}
}

void track_i(u16 time)
{
	u8 i;
	for(i=0;i<time;i++)
		{
			track1();
		}
}
void xunji(u16 time)//����ѭ��
{
	u16 i;
	for(i=0;i<time;i++)
		{
			track_back();
		}
	
}

 void test()
 {
		while(track_right==0)
		{
			 			track();
		}
		while(track_right!=0)
		{
			stop();
			break;
		}
}
 void test_back()
 {
			while(track_right==0)
		{
      track_back();
		}
		while(track_right!=0)
		{
			stop();
			break;
		}
		
 }
 void test_right()//�е���
{
	while(QL==0)
		{
				track();
		}
		while(QL!=0)
		{
			stop();
			break;
		}
}
 void test_no()//�е���
{
	while(QL==1)
		{
				track();
		}
		while(QL!=1)
		{
			stop();
			break;
		}
}

void test_zhong()//�е���
{
	while(QL!=1)
		{
				Turn_weizhuan(0);
		}
		while(QL==1)
		{
			stop();
			break;
		}
}

void test_go()//�е���
{
	while(QL==0)
		{
				Direction(1,1);
				Speed(1420,1500);
		}
		while(QL!=0)
		{
			stop();
			break;
		}
}
 void test_left()//�е���
{
	while(QR==0)
		{
				track();
		}
		while(QR!=0)
		{
			stop();
			break;
		}
}

void turn_adgust(u8 left,u8 right)
{
	if(left==1)    //��߼�⵽ /  �ұ�û��⵽
	{
			if(right==0)
			{
					while(track_left==0)
					{
						Turn_weizhuan(0);
					}
					while(track_left!=0)
					{
						stop();
						break;
					}
					
			}
	}
	
	else if(left==0)
	{
			if(right==1)
			{
					while(track_right==0)
					{
						Turn_weizhuan(1);
					}
					while(track_right!=0)
					{
						stop();
						break;
					}
					
			}
	}
}
void turn_adust()
{
	while(track_left ==0 && track_right==1)
	{
		Turn_weizhuan(0);
		while(track_left ==1 && track_right==1)
		{
			stop();
			break;
		}
	}
	while(track_left ==1 && track_right==0)
	{
		Turn_weizhuan(1);
		while(track_left ==1 && track_right==1)
		{
			stop();
			break;
		}
	}
	while(track_left ==0 && track_right==0)
	{
		while(QR==0)
		{
			Turn_weizhuan(0);
			while(track_left ==1 && track_right==1)
			{
				stop();
				break;
			}
			
		}
		while(QR!=0)
		{
			Turn_weizhuan(1);
			while(track_left ==1 && track_right==1)
			{
				stop();
				break;
			}
		}
	}
	
	
}

void turn2()//ת�Ǽ��
{
	
	if(track_left==1&&track_right==0)
	{
		
			Turn_weizhuan(1);
	
		if(track_left==1&&track_right==1)
			{
		    stop();
			}
	}
	else if(track_left==0&&track_right==1)
	{
		
			Turn_weizhuan(0);
		
		if(track_left==1&&track_right==1)
			{
		   stop();
			}		
	}
	else if(track_left==0&&track_right==0)
{
	if(QR==1)
	{
				Turn_weizhuan(1);
				if(track_left==1&&track_right==1)
					{
					 stop();
					}		
	}
	else
		{
				Turn_weizhuan(0);
				if(track_left==1&&track_right==1)
					{
					 stop();
					}		
		}
}
	
	else
				stop();	
}	


void turn3()//ת�Ǽ��
{
	
	while(QL==0)
		{
			 			Turn_weizhuan(0);
		}
		while(QL!=0)
		{
			stop();
			break;
		}
	}
		

void turn180()
{
	stop();
	Turn90(0,970);  //90��
	stop();
	
	test_right(); //�е���
	
	stop();
	Turn90(0,960);  //90��
	stop();
}




void turn(u8 direction) //��һ�μ������ת
{	
	if(direction==0) //  ��ת
	{
		Turn_weizhuan(0);
	  delay_ms(250,0);
		 //΢��ת
			while(QR==0)//δ��⵽
		{
			Turn_weizhuan(0);			
    }
		while(QR==1)//��⵽
		{
			stop();
			break ;
		}
	}
		else if(direction==1)//��ת
	{
		Turn_weizhuan(1);
  	delay_ms(360,0);
		stop();//΢��ת
			while(QR==0)
		{
			Turn_weizhuan(1);			
    }
		while(QR==1)
		{
			stop();
			break ;
		}
	}		
			while(QR==0)
	{
			Turn_weizhuan(1);			
    }
		while(QR==1)
		{
			stop();
			break ;
		}
	}		
		
	
		