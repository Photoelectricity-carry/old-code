#ifndef __TRACK_H
#define __TRACK_H

#include "sys.h"
void Track_delay(u16 time);
void track_shun();
void track_ni();
void track();
void track1();
void track2();
void track_back();
void xunji(u16 time);
 void test();
 void turn180();
 void test_back();
void test_right();
void test_left();
void zhongdian();
void turn(u8 drection);
void turn2();//ת�Ǽ��
void turn3();//ת�Ǽ��
void test_zhong();
void test_no();
void turn_adgust(u8 left,u8 right);
void test_go();
void turn_adust();
#define A0  PGin(0)
#define A1  PGin(1)
#define A2  PGin(2)
#define A3  PGin(3) 
#define A4  PGin(4) 
#define B0  PEin(0)
#define B1  PEin(1)
#define B2  PEin(2)
#define B3  PEin(3) 

#define QL  PEin(5)
#define QR  PEin(4)
#define track_right PEin(6)
#define track_left  PEin(9)
#endif

