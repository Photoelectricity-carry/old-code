#include <Move.h>
#include "speed.h"
#include "direction.h"
#include "TRACK.h"
#include "turn.h"
#include "gouzi.h"

//   /******************************************************************************
//* ��������:   void Turn_Left(uint16 n)
//* ��;:       ���Ƴ�����ת�ĺ�����
//* ע�⣺
//******************************************************************************/

//  /******************************************************************************
//* ��������:   void Turn_right(uint16 n)
//* ��;:       ���Ƴ��嵹�˵ĺ�����
//* ע�⣺
//******************************************************************************/
 u8 x=0;
void A_colour_go(u16 n)
  {
  	 if	(n==0)		     		   //��ɫ	
	 {
	
		xunji(400);
		test_back(); 
		test_right();

		qianjin(100);
		
		Turn45(1,460);  //
		stop();
		
		houtui(250);
//		houtui(200);
		stop();
		
		turn_adgust(0,1);
		 
		Track_delay(150);	   //1
		test();
		 
		houtui(100);
		jiazi(0); //���Ӵ�
		stop();

		xunji(180);
	
    test_back();
		
		test_right();
	
//		houtui(300);	
//		 stop();
		
		 Turn135(0,1600);  //��ת135
	
		  Turn135(0,300);  //��ת135
	
		 
		 houtui(200);	
		 turn_adgust(1,0);
		
		Track_delay(400);	   //1
		test();
	}
	 else if (n==1)		  		   //��ɫ
	 {
			jiazi(0);
		 
			stop();
		 
			xunji(400); //Ѱ��

			test_back(); //�е���

			test_right(); //�е���
		
			houtui(150);
		 
			Turn90(0,990);
			stop();
		 
//			houtui(250);
		 
		 
			turn_adgust(1,0);

			Track_delay(400);	   //2

			test();

			x=1;
	 }	 
	  else if (n==2)	 //��ɫ
	 {			
	 
		xunji(400);
		test_back(); 
		 
		test_right();
		houtui(400);

		stop();
		Turn135(1,1750);  //135
		stop();
		 
		houtui(220);
		 
	  Turn135(1,300);  //135
		stop();
		 
		houtui(200);
		
		 	
		turn_adgust(0,1);

		Track_delay(110);	   //1
		test();
		
		houtui(160);
		
		jiazi(0); //���Ӵ�
		stop();

		xunji(180);
	
		test_back ();
		test_right();
		
		houtui(400);

		stop();
		Turn135(1,1750);  //135
		stop();
		 
		houtui(300);
		 
	  Turn135(1,200);  //135
		stop();
		 
		houtui(200);
		
		 	
		turn_adgust(0,1);

		Track_delay(300);	   //1
		test();
		
}	 
	 else if (n==3)		//��ɫ	    
	 {
		 	
		xunji(350);
		test_back(); 
		test_right();	
  	
		 houtui(300);	
		 stop();
		
		 Turn135(0,1500);  //��ת135
		 stop();
		 
		 houtui(350);	
		 turn_adgust(1,0);

		Track_delay(110);	   //1
		test();
		 
		houtui(100);
		 
		jiazi(0); //���Ӵ�
		stop();

		xunji(180);
		stop();
		
    test_back();
		
		test_right();

		qianjin(100);
		
		Turn45(1,400);  //
		stop();
		houtui (180);
		stop();
		
		turn_adgust(0,1);
		
		Track_delay(300);	   //1
		test();
		
	 }
	 else if (n==4)		  //��ɫ
	 {

		xunji(400);
		test_back(); 

//	
//		weiqianjin();
	
		houtui (135);		 
		Turn45(0,500);  //��ת45
		stop();
		
//		weihoutui();
		houtui(100);
		 
		turn_adgust(1,0);


		Track_delay(110);	   //1
		test();
		
		 weihoutui1();
	 
		jiazi(0); //���Ӵ�
		stop();

		xunji(180);
		test_back();
		stop();
		
//		test_right(); //�е���
	
//		weiqianjin();
//			
		houtui (135);

		Turn45(0,480);  //��ת45
		stop();
		
		houtui(100);
	
		turn_adgust(1,0);

		
		Track_delay(300);	   //1
		test();
		
		
   }
  }
  void B_colour_go(u16 n)
  {
     if	(n==0)		      //��ɫ 
	 {
		xunji(400);
	  test_back();  
		test_right();
		
		houtui(400);
		 
		stop();
		Turn135(1,1600);  //135
		stop();
		 houtui(300);
		Turn135(1,300);  //135
	  stop();
		houtui(100);

		 
		turn_adgust(0,1);
		 
		 
		 
		Track_delay(150);	   //1
		test();
		 
		houtui (100);
		jiazi(0); //���Ӵ�
		stop();

		xunji(180);
	
    test_back ();
		test_right();
		 
			houtui(250);
		 
		stop();
		Turn135(1,1500);  //135
		stop();
//		 houtui(200);
		Turn135(1,300);  //135
	  stop();
		houtui(230);

		 
		turn_adgust(0,1);
		 
		
		Track_delay(400);	   //1
		test();
   }		 
	 else if (n==1)		   //��ɫ	  
	 {
				jiazi(0);
		 
			stop();
		 
			xunji(400); //Ѱ��

			test_back(); //�е���

			test_right(); //�е���
		
			houtui(150);
		 
			Turn90(0,990);
			stop();
		 
//			houtui(250);
		 
		 
			turn_adgust(1,0);

			Track_delay(400);	   //2

			test();

			x=2;
	 }	 
	 else if (n==2)	 //��ɫ		
	 {	
		xunji(400);
		test_back(); 
		 
		test_right();
		 
//		houtui(400);	
//		 stop();
		
		 Turn135(0,1500);  //��ת135
		 stop();
		 
//		 houtui(200);	
		 
		 Turn135(0,250);  //��ת135
		 stop();
		 
		 houtui(200);	
		 turn_adgust(1,0);
		 
		Track_delay(110);	   //1
		test();
		
		houtui(120);
		
		jiazi(0); //���Ӵ�
		stop();

		xunji(180);
		test_back();
		test_right();

		weiqianjin();
		
		Turn45(1,460);  //
		stop();
		
		houtui(200);
//		weihoutui2();
		
		stop();
		
		turn_adgust(0,1);
		
		Track_delay(300);	   //2
		test();
		
	 }	 
	 else if (n==3)		//��ɫ	  
	 {
	  xunji(400);
		test_back(); 
		test_right ();
		 
//		houtui (135);		 
		Turn45(0,500);  //��ת45
		stop();
		
//		weihoutui();
//		qianjin(150);
		 
		turn_adgust(1,0);

		Track_delay(110);	   //1
		test();
		weihoutui1 ();
		jiazi(0); //���Ӵ�
		stop();

		xunji(180);
		 
		test_back(); 
		test_right ();
		
		Turn45(0,500);  //��ת45
		stop();
		
//		weihoutui();
//		qianjin(150);
		 
		turn_adgust(1,0);

		
		Track_delay(300);	   //1
		test();
		
	 }
	 else if (n==4)		   //��ɫ 
	 { 
	  xunji(400);
		test_back(); 
		test_right();

		qianjin (100);
	
		Turn45(1,450);  
		stop();
		 
		houtui(300);
		turn_adgust(0,1);
		 
		Track_delay(150);	   //1
		 
		test();
		 
		houtui (100);
		 
		jiazi(0); //���Ӵ�
		stop();

		xunji(180);
	  test_back(); 
		
		test_right();
		
	
//		houtui(300);	
//		 stop();
		
		 Turn135(0,1600);  //��ת135
		 stop();
		 
		  houtui(100);
			
		  Turn135(0,300);  //��ת135
		 stop();
		 
//		 	weiqianjin ();
		 
		 houtui(100);	
		 turn_adgust(1,0);
		
		Track_delay(400);	   //1
		test();
   }
  }
   void C_colour_go(u16 n)
   {
   	 if	(n==0)		       //��ɫ	 
	 {
	  xunji(400);
	  test_back();  
		test_right();
		 
//		qianjin(200);	
//		 stop();
		
		 Turn135(0,1600);  //��ת135
		 stop();
		 
	 	qianjin(200);
		 
		  Turn135(0,300);  //��ת135
		 stop();
		 
		 houtui(200);	
		 turn_adgust(1,0);
		 
		Track_delay(110);	   //1
		test();
		
		 houtui(100);
		 
		jiazi(0); //���Ӵ�
		stop();

		xunji(180);
   	test_back(); 
		test_right ();
		 
		weihoutui();
	
		Turn45(1,450);  //
		stop();
		 
//		weiqianjin();
		
		turn_adgust(0,1);
		
		Track_delay(300);	   //1
		test();
	 }
	 else if (n==1)		   //��ɫ	 
	 {
			jiazi(0);
		 
			stop();
		 
			xunji(400); //Ѱ��

			test_back(); //�е���

			test_right(); //�е���
		
			houtui(150);
		 
			Turn90(0,990);
			stop();
		 
//			houtui(250);
		 
		 
			turn_adgust(1,0);

			Track_delay(400);	   //2

			test();
			x=3;
	 }	 
	  else if (n==2)	   //��ɫ	  
	 {	
	  xunji(400);
		test_back(); 
		test_right ();
		 
		houtui (135);		 
		Turn45(0,500);  //��ת45
		stop();
		
//		weihoutui();
//		weihoutui();
		 qianjin(200);
		turn_adgust(1,0);
		 
		Track_delay(110);	   //1
		test();
		houtui(100);
		 
		jiazi(0); //���Ӵ�
		stop();

		xunji(180);
		test_back(); 
		test_right ();
		
		houtui (135);		 
		Turn45(0,500);  //��ת45
		stop();
		
//		weihoutui();
//		weihoutui();
		 qianjin(200);
		turn_adgust(1,0);
		
		Track_delay(300);	   //2
		test();
	 }	 
	 else if (n==3)		   //��ɫ	  
	 {
	  xunji(400);
		test_back(); 
		test_right ();
		stop();
		weiqianjin();
		
	
		Turn45(1,450);  //
		stop();
		 
		houtui(200);
		
		turn_adgust(0,1);
		Track_delay(110);	   //1
		test();
		 
		houtui(100);
		 
		jiazi(0); //���Ӵ�
		stop();

		xunji(180);
		test_back(); 
		 
		test_right();
//		 houtui(200);	
		 stop();
		
		 Turn135(0,1350);  //��ת135
		 stop();
		 
		 Turn135(0,400);  //��ת135
		 stop();
		 
		 houtui(110);	
		 turn_adgust(1,0);

		
		Track_delay(300);	   //1
		test();
		
	 }
	 else if (n==4)		   //��ɫ	
	 {
			xunji(400);
			test_back ();
		 
			test_right();
		houtui(300);
		 
		stop();
		Turn135(1,1600);  //135
		stop();
		 houtui(200);
		Turn135(1,300);  //135
	  stop();
//		houtui(200);
		 houtui(300);
//		  houtui(220);
		stop();
		 
		turn_adgust(0,1);

			Track_delay(110);	   //1
			test();
			houtui(100);
			jiazi(0); //���Ӵ�
			stop();

			xunji(40);
			test_back ();
			test_right();
		houtui(300);
		 
		stop();
		Turn135(1,1600);  //135
		stop();
		 houtui(200);
		Turn135(1,300);  //135
	  stop();
		houtui(200);
//		 houtui(300);
//		  houtui(220);
		stop();
		 
		turn_adgust(0,1);

			Track_delay(300);	   //1
			test();
    }
   }
 void D_colour_go(u16 n)
	{
	 if	(n==0)		       //��ɫ   
	 {
	  
		xunji(400);
	  test_back();  
		test_right();
		
		weiqianjin();
			
		Turn45(0,500);  //��ת45
		stop();
		
		
		turn_adgust(1,0);
		 
		Track_delay(150);	   //1
		test();
		weiqianjin();
		jiazi(0); //���Ӵ�
		stop();

		xunji(110);
   	test_back(); 
		test_right ();
		
		Turn(1,600);  // ��ת90
		stop();
		
		 houtui(200);
		 
		turn_adgust(0,1);
		
		
		test_back(); 
		test_right ();
		
			Turn(1,600);  // ��ת90
		stop();
		
		 houtui(200);
		 
		turn_adgust(0,1);
		
	 }
	 else if (n==1)		   //��ɫ	 
	 {
			jiazi(1);//��������

			right_zhua();
			stop();

			xunji(22);   //����ѭ����zhong��
			test_back ();
			weihoutui ();
			weihoutui ();
			stop();
			Turn135(1,1500);  //��ת135
			stop();
			x=4;
	 }	 
	  else if (n==2)	   //��ɫ	  
	 {	
	  xunji(400);   //����ѭ����zhong��
		test_back();
	
		weihoutui();
	
		Turn45(1,450);  //
		stop();
		 
//		weiqianjin();
		
		turn_adgust(0,1);
		 
	  Track_delay(110); //ǰ��ѭ������ɫ�������
		test();
	
		 
		houtui(120);
		stop();
		
		jiazi(0);//����
		stop();
		 
		xunji(180);   //����Ѱ�����е�
		test_back();
		 
		Turn(1,600);  // ��ת90
		stop();
		
		 houtui(200);
		 
		turn_adgust(0,1);
		 
	
	 }	 
	 else if (n==3)		   //��ɫ	 
	 {
		xunji(400);
		test_back(); 
		test_right ();
		houtui(250);
		 
		stop();
		Turn135(1,1500);  //135
		stop();
//		 houtui(200);
		Turn135(1,300);  //135
	  stop();
		houtui(255);

		 
		turn_adgust(0,1);
		 
		Track_delay(110);	   //1
		test();
		 
		houtui(100);
		 
		jiazi(0); //���Ӵ�
		stop();

		xunji(180);
		test_back(); 
		 
		test_right();
//		 houtui(200);	
		 stop();
		
		
	 }
	 else if (n==4)		   //��ɫ	 
	 {

		 xunji(400);
		test_back ();
		 
		test_right();
		
		 Turn135(0,1600);  //��ת135
		 stop();
		 
	 	qianjin(200);
		 
		  Turn135(0,300);  //��ת135
		 stop();
		 
		 houtui(300);	
		 turn_adgust(1,0);

			Track_delay(110);	   //1
			test();
			houtui(100);
			jiazi(0); //���Ӵ�
			stop();

			xunji(40);
			test_back ();
			test_right();
//		  houtui(150);
		 
			Turn90(0,1150);
			stop();
		 
			qianjin(170);
		 
			turn_adgust(1,0);

			
     }  
}

void blank()
{
	if(x==1)
	{
		test_back ();
		weihoutui ();
		weihoutui ();
		stop();
		Turn135(1,1500);  //��ת135
		stop();
		
		Track_delay(300);	   //1
		test();

		
		jiazi(1); //����xia

		stop();

		xunji(80);
		test_back(); 
		test_right();

		stop();
		
		Turn90(0,800);  //90��
    stop();

		weihoutui2();
		stop();
		
		jiazi(0);	
		
		xunji(80);
		test_back(); 
		
		
	}
	else if(x==2)
	{
	
		test_back(); 
		
		weihoutui2 ();
		
		jiazi(0);
		
		xunji(80);
		test_back(); 
	}
	else if(x==3)
	{
		Turn90(1,750);  //90��
	 	stop();
		
		test_back(); 
		
		weihoutui2 ();
		
		jiazi(0);
		
		xunji(80);
		test_back();
	}
	
	else if(x==4)
	{
		xunji(80);
		test_back();
		
		Turn135(0,1450);  //��ת180
		stop();
		
		test_back(); 
		
		weihoutui2 ();
		jiazi(0);
		
		xunji(80);
		test_back();
		
	}
	
	else
	{
		Turn45(1,460);  //youת45
		stop();
		
		xunji(80);
		
		test_back();
	}
	
}

//void white(u8 n1,u8 n2,u8 n3)
//{
//		if(n1==0 || n2==0 || n3==0)
//		{
//			Turn(0,100); //��ת90
//			stop();
//			Track_delay(12); 
//	  	stop();
//			if(n1==0)
//			{
//				gouzi5(0); //���ӷ�
//				xunji(3);   //����Ѱ�� 
//				stop();
//				Turn(1,100); //��ת90
//			  stop();
//			}
//			else if(n2==0)
//			{
//				gouzi5(0); //�ҹ��ӷ�
//				xunji(3);   //����Ѱ�� 
//				stop();
//				Turn(1,100); //��ת90
//			  stop();
//			}
//			else if(n3==0)
//			{
//				jiazi(0); //�ҹ��ӷ�
//				xunji(3);   //����Ѱ�� 
//				stop();
//				Turn(1,100); //��ת90
//			  stop();
//			}
//		}	
//		else
//		{
//			stop();
//		}
//}

//void red(u8 n1,u8 n2,u8 n3)
//{
//		if(n1==2 || n2==2 || n3==2)
//		{
//			Turn(1,100); //youת90
//			stop();
//			Track_delay(12); 
//	  	stop();
//			Turn(1,100); //youת90
//			stop();
//			Track_delay(12); 
//	  	stop();
//			Turn(1,100); //youת180
//			stop();
//			
//			if(n1==2)
//			{
//				gouzi5(0); //���ӷ�
//				
//				Direction (0,0);
//				Speed(1000,1000);
//				delay_ms(1000,0);
//				
//				Turn(1,100); //youת180
//				stop();
//				
//				Track_delay(12); 
//				stop();
//				
//			}
//			else if(n2==2)
//			{
//				gouzi5(0); //�ҹ��ӷ�
//				Direction (0,0);
//				Speed(1000,1000);
//				delay_ms(1000,0);
//				
//				Turn(1,100); //youת180
//				stop();
//				
//				Track_delay(12); 
//				stop();
//			}
//			else if(n3==2)
//			{
//				jiazi(0); //�ҹ��ӷ�
//				Direction (0,0);
//				Speed(1000,1000);
//				delay_ms(1000,0);
//				
//				Turn(1,100); //youת180
//				stop();
//				
//				Track_delay(12); 
//				stop();
//			}
//		}	
//		else
//		{
//			Turn(1,100); //youת90
//			stop();
//			Track_delay(12); 
//			stop();
//			Turn(1,100); //youת90
//			stop();
//			Track_delay(12); //���̵�
//	  	stop();
//		}
//}
//void green(u8 n1,u8 n2,u8 n3)
//{
//		if(n1==3 || n2==3 || n3==3)
//		{
//			Turn(1,100); //youת90
//			stop();
//			Track_delay(12); 
//	  	stop();
//			Turn(1,100); //youת180
//			stop();
//			if(n1==3)
//			{
//				jiazi(0); //���ӷ�
//				Direction (0,0);
//				Speed(1000,1000);
//				delay_ms(1000,0);
//				
//				Turn(1,100); //youת180
//				stop();
//				
//				Track_delay(12); 
//				stop();
//			}
//			else if(n2==3)
//			{
//				gouzi5(0); //�ҹ��ӷ�
//				Direction (0,0);
//				Speed(1000,1000);
//				delay_ms(1000,0);
//				
//				Turn(1,100); //youת180
//				stop();
//				
//				Track_delay(12); 
//				stop();
//			}
//			else if(n3==3)
//			{
//				jiazi(0); //�ҹ��ӷ�
//				Direction (0,0);
//				Speed(1000,1000);
//				delay_ms(1000,0);
//				
//				Turn(1,100); //youת180
//				stop();
//				
//				Track_delay(12); 
//				stop();
//			}
//		}	
//		else
//		{
//			Turn(1,100); //youת90
//			stop();
//			Track_delay(12); //������
//	  	stop();
//		}
//}
//void blue(u8 n1,u8 n2,u8 n3)
//{
//		if(n1==4 || n2==4 || n3==4)
//		{
//			if(n1==4)
//			{
//				jiazi(0); //���ӷ�
//				Direction (0,0);
//				Speed(1000,1000);
//				delay_ms(1000,0);
//				
//				Turn(1,100); //youת180
//				stop();
//				
//				Track_delay(12); //������ſ�
//				stop();
//			}
//			else if(n2==4)
//			{
//				gouzi5(0); //�ҹ��ӷ�
//			Direction (0,0);
//				Speed(1000,1000);
//				delay_ms(1000,0);
//				
//				Turn(1,100); //youת180
//				stop();
//				
//				Track_delay(12); //������ſ�
//				stop();
//			}
//			else if(n3==4)
//			{
//				jiazi(0); //���ӷ�
//				Direction (0,0);
//				Speed(1000,1000);
//				delay_ms(1000,0);
//				
//				Turn(1,100); //youת180
//				stop();
//				
//				Track_delay(12); //������ſ�
//				stop();
//			}
//		}	
//		else
//		{
//			  Turn(1,100); //youת180
//				stop();
//				
//				Track_delay(12); //������ſ�
//				stop();
//		}
//}



