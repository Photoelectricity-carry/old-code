#include "sys.h"
#include "usmart.h"
#include "port.h"
#include "usart.h"
#include "delay.h"
#include "TRACK.h"
#include "stm32f10x.h"
#include "TCS3200.h"
#include "direction.h"
#include "exit.h"
#include "speed.h"
#include "pwm.h"
#include "move.h"
#include "turn.h"
#include "gouzi.h"
#include "control.h"

int main ()			          //�����޸�
{
u16 n=0,n1=0,n2=0,n3=0,m;
	delay_init();
	EXTIX_Init();
	NVIC_Configuration(); 	 //����NVIC�жϷ���2:2λ��ռ���ȼ���2λ��Ӧ���ȼ�
	uart_init(9600);	 			 //���ڳ�ʼ��Ϊ9600
	usmart_dev.init(72);	   //��ʼ��USMART                              *
	Port_Init();
	TCS3200_Init(1,1);
	TIM4_PWM_CH1_Init(7200,0);//72000000
	TIM4_PWM_CH3_Init(7200,0);
	
//	 stop();	
	
//	 Track_delay(650);//ǰ��ѭ��
	
//	 xunji(90);//����ѭ��
	
//	 stop();


	
//	Turn135(0,1820);//��ת135
		 


//	Turn45(1,460);  //��ת135
//  stop();
//	
//	stop();
//Turn45(0,450);  //��ת45
//		stop();
//		turn_adgust(1,0);
//		turn_adgust(1,0);
//			stop();
//	   Turn90(0,800);  //90��
//			stop();
//		turn_adgust(1,0);
//stop();
//Turn90(1,750);  //90��
//			stop();
//		turn_adgust(0,1);
//stop();
//Turn135(1,1100);  //90��
//			stop();
//		weihoutui2();
//		test_back();
//	turn_adgust(0,1);

//	stop();
//	test_right(); //�е���
//	weiqianjin ();\
//	weiqianjin ();
//Turn90(0,1090);
//	stop();
//	
//		Direction(0,1); //1 ��ǰ 0 ���
//	  Speed(1500,1500);
//	  delay_ms(1870,0);
//	  Speed(500,500);
//	  delay_ms(100,0);
	
//	stop();
//	Turn135(1,1640);
//	stop();
	
	
//	gouzi1(1950);
//	delay_ms(1000,0);
//	delay_ms(1000,0);
//	gouzi1(500); 
	
//		gouzi31(1500);  //�� //����
//		delay_ms(1000,0);
//		delay_ms(1000,0);
//		gouzi31(510);

//	gouzi21(600);  //shang  //����
//	delay_ms(1000,0);
//	gouzi21(1700);  //xia
////		

//		gouzi41(1700);   //��  //����
//		delay_ms(1000,0);
//		delay_ms(1000,0);
//		gouzi41(700);     //��
		
//		gouzi51(1700);  //shang  //����
//		delay_ms(1000,0);
//		delay_ms(1000,0);
//		gouzi51(700);  //xia

// left_zhua();
//	left_fang();
////   jiazi(1);
// WhiteBalance();
clour_disguish();
//left_zhua();
//left_fang();
//right_zhua();
//right_fang();


////while(1)

// stop();
// Direction (1,1);
// Speed(935,1000);
// delay_ms(1000,0);
// delay_ms(1000,0);
// delay_ms(1000,0);
// delay_ms(1000,0);
// delay_ms(1000,0);
// delay_ms(1000,0);
// delay_ms(1000,0);
// delay_ms(1000,0);
//	stop();

// Direction (1,1);
// Speed(1200,1300);
// delay_ms(1000,0);
// delay_ms(1000,0);
// delay_ms(1000,0);
// delay_ms(1000,0);
// delay_ms(1000,0);
// delay_ms(1000,0);
// delay_ms(1000,0);
// delay_ms(1000,0);
// delay_ms(1000,0);
//	stop();
//	}
// jiazi(0); //���Ӵ�
//delay_ms(1000,0);

//jiazi(1); //���Ӵ�
//Turn45(0,390);   // ��ת45��  
////	
//while(1)
//{
//	 stop(); 
//	 Track_delay(700);
//	test ();
//	 stop();
//   xunji(500);	 //Ѱ��
//	test_back();
//	 stop();
//}
//left45();
//right45();
//left90();
//right90();
//right135();
//	//����ʼ 
	
	 
//	 jiazi(0); //���Ӵ�

//	 test_right(); //�е���
	 
//		Track_delay(40); //Ѱ��
//	 
//	 test_right(); //�е���
////	
////	 qianjin(80);
//		
//  	Turn45(0,500);  //��ת45
//		
//		
//	
//		houtui (180);


//		turn_adgust(1,0);

//		
//		Track_delay(300);	   //1
//		test();

//		
//		jiazi(1); //����xia

//		stop();


//	  n = clour_disguish();     //1����ɫʶ��
//		A_colour_go(0); 

//		 
//		 jiazi(1); //���Ӻ���
//	   stop();
//	   n = clour_disguish();     //2����ɫʶ��
//     B_colour_go(0); 
//		 stop();
		
//		 jiazi(1);
//		 stop();
//	   n = clour_disguish();     //3����ɫʶ��
//     C_colour_go(n); 
//		 stop();
//		 
//		 jiazi(1);
//		 stop();
//	   n = clour_disguish();     //4����ɫʶ��
//     D_colour_go(n); 
//		 stop();
//		 
////		 xunji(5);    //����ѭ���ź�ɫ���
//		 test_back();
//		 
//		 right_fang();
//		 
//		 xunji(10);    //����ѭ���Ű�ɫ���
//		 test_back();
//		 
//		 left_fang();
//		 
//		 weihoutui();
//		 
//		 Turn (0,180);//180
//		 stop();
		 
		 
//		 //�ڶ���
//		 gouzi5(1);//���� 
//		 jiazi(1); //   
//		 n1 = clour_disguish();     //����ɫʶ��
//		 
////     E_colour_go(n); 
//		 
//		 Direction (0,0);
//		 Speed(1000,1000);
//		 delay_ms(10000,n3);
//			red(n1,n2,n3);
//		  green(n1,n2,n3);
//			blue(n1,n2,n3);
//			
//			Turn(1,366);  //youת90
//		  stop(); 
//			Track_delay(13);
//			stop();
}