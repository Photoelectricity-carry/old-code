#include "direction.h"
#include "speed.h"
#include "delay.h"
void Direction(u8 left,u8 right)
{
 	PBout(10)=left;                      
	PBout(11)=right; 				  
} 

