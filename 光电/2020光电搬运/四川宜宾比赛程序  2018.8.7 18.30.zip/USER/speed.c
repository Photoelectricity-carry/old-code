#include "speed.h"
#include "stm32f10x_tim.h" 
#include "pwm.h"
#include "direction.h"
#include "delay.h"
void Speed(u16 Left,u16 Right)  
{
  TIM_SetCompare1(TIM4,Left);		 
  TIM_SetCompare3(TIM4,Right);	
}

void stop()
{
	Direction(1,1);
	Speed(10,10);
	delay_ms(500,0);
}

void weihoutui()
{
	Direction(0,0);
	Speed(1100,1200);
	delay_ms(160,0);
	stop();
}
void weihoutui2()
{
	Direction(0,0);
	Speed(1080,1200);
	delay_ms(400,0);
	stop();
}
void weihoutui1()
{
	Direction(0,0);
	Speed(1080,1200);
	delay_ms(100,0);
	stop();
}

void weiqianjin()
{
	Direction(1,1);
	Speed(1200,1300);
	delay_ms(50,0);
	stop();
}
void qianjin(u16 time)
{
	Direction(1,1);
	Speed(1300,1300);
	delay_ms(time,0);
	stop();
}

void houtui(u16 time)
{
	Direction(0,0);
	Speed(1300,1300);
	delay_ms(time,0);
	stop();
}