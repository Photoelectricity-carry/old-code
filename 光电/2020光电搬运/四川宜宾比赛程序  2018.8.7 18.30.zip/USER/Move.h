#ifndef _Move_H
#define _Move_H

#include <usart.h>
#include <sys.h>
#include <delay.h>
//#include <TRACK.h>
void For_Along(u16 time);
void zuozhuan(u16 x);
//void youzhuan(u16 x);
void zhizou(u16 x);
void blank();
void A_colour_go(u16 n);
void B_colour_go(u16 n);
void C_colour_go(u16 n);
void D_colour_go(u16 n);
void go_stright_times(u16 time, u16 times);
void car_back(u16 time, u16 times);
void heise();
void white(u8 n1,u8 n2,u8 n3);
void red(u8 n1,u8 n2,u8 n3);
void green(u8 n1,u8 n2,u8 n3);
void blue(u8 n1,u8 n2,u8 n3);
#endif
