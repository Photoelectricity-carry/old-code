#include "turn.h"
#include "speed.h"
#include "direction.h"
#include "delay.h"
//void Turn(u8 direction,u16 time)//180
//{
//	if(direction==0)  //��ת
//	{
//	  Direction(0,1); //1 ��ǰ 0 ���
//	  Speed(1500,1500);
//	  delay_ms(time,0);
//	  Speed(500,500);
//	  delay_ms(100,0);
//	}
//	if(direction==1)   //��ת
//	{
//	  Direction(1,0);
//	  Speed(1920,2000);
//	  delay_ms(time,0);
//	  Speed(500,500);
//	  delay_ms(100,0);
//	}

//}
void Turnwei()
{

	  Direction(0,1); //1 ��ǰ 0 ���
	  Speed(1400,1600);
	  delay_ms(60,0);
	  Speed(500,500);
	  delay_ms(100,0);
	

}
void Turn45(u8 direction,u16 time)
{
	if(direction==0)  //��ת
	{
	  Direction(0,1); //1 ��ǰ 0 ���
	  Speed(1950,1800);//1100.2000
	  delay_ms(time,0);
	  Speed(500,500);
	  delay_ms(100,0);
	}
	if(direction==1)   //��ת
	{
	  Direction(1,0);
	  Speed(1900,2150);
	  delay_ms(time,0);
	  Speed(500,500);
	  delay_ms(100,0);
	}

}

void Turn(u8 direction,u16 time)
{
	if(direction==0)  //��ת
	{
	  Direction(0,1); //1 ��ǰ 0 ���
	  Speed(1620,1450);
	  delay_ms(time,0);
	  Speed(500,500);
	  delay_ms(100,0);
	}
	
	if(direction==1)   //��ת
	{
	  Direction(1,0);
	  Speed(1920,2000);
	  delay_ms(time,0);
	  Speed(500,500);
	  delay_ms(100,0);
	}

}
void Turn135(u8 direction,u16 time)
{
	if(direction==0)  //��ת
	{
	  Direction(0,1); //1 ��ǰ 0 ���
	  Speed(2200,2300);
	  delay_ms(time,0);
	  Speed(500,500);
	  delay_ms(100,0);
	}
	if(direction==1)   //��ת
	{
	  Direction(1,0);
	  Speed(2100,2330);
	  delay_ms(time,0);
	  Speed(500,500);
	  delay_ms(100,0);
	}

}
void Turn180()
{
	  stop();
		Turn90(0,1000);
		test_zhong(); //�е���
	  stop();
		Turn90(0,1300);
	  stop();
}


void Turn90(u8 direction,u16 time)
{
	if(direction==0)  //��ת
	{
	  Direction(0,1); //1 ��ǰ 0 ���
	  Speed(2100,2000);
	  delay_ms(time,0);
	  Speed(500,500);
	  delay_ms(100,0);
	}
	if(direction==1)   //��ת
	{
	  Direction(1,0);
	  Speed(1900,2200);
	  delay_ms(time,0);
	  Speed(500,500);
	  delay_ms(100,0);
	}

}

void Turn_weizhuan(u8 direction)
{
	if(direction==0)  //��ת
	{
	  Direction(0,1); //1 ��ǰ 0 ���
	  Speed(1950,1800);//1100.2000

	}
	if(direction==1)   //��ת
	{
	   Direction(1,0);
	  Speed(1900,2150);
	}
}

