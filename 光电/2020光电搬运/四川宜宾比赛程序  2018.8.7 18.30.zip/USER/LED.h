#ifndef _LED_H
#define _LED_H
#include "stm32f10x_gpio.h"
#include "delay.h"
//����LED�Ķ˿ڶ���
	#define LED_0 PDout(13)	 //D5
	#define LED_1 PGout(14)	 //D2

	//LED�ĳ�ʼ������
	void LED_Init(void);
	void led_r(void);
	void led_g(void);
	void led_b(void);
	void led_w(void);
	void led_black(void);
#endif

