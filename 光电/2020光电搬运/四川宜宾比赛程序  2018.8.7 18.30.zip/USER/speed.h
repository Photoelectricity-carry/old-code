#ifndef __SPEED_H
#define __SPEED_H

#include "sys.h"

void Speed(u16 Left,u16 Right);
void stop();
void weihoutui();
void weiqianjin();
void qianjin(u16 time);
void weihoutui1();
void weihoutui2();
void houtui(u16 time);
#endif



